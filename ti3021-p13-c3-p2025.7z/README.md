# ti3021-p13-c3-p2025
POO (programación orientada a objeto)
